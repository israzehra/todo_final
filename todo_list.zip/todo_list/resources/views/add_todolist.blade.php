@extends('layouts.master')
@section('content')

{!! Form::open(array('url' => route('todolist.index'), 'method' => 'post')) !!}
{!! Form::text('task_name') !!}
{!! Form::submit('add') !!}
{!! Form::close() !!}
@endsection