@extends('layouts.master')
@section('content')

{!! Form::open(array('url' => route('todolist.update' , ['todolist' =>$todolist->id]), 'method' => 'put')) !!}
{!! Form::text('task_name' , $todolist->todo_tasks) !!}
{!! Form::submit('add') !!}
{!! Form::close() !!}
@endsection