@extends('layouts.master')

@section('content')
<a href="{{ route('todolist.create')}}"><i style="margin-left: 78%;
    font-size: 44px; background-color:rgba(137, 196, 244, 1) ;" class="fas fa-plus-square"></i></a>
<table border="1" cellpadding="10" cellspacing="0" style="margin-left: 17%;
    width: 65%;">
<thead>
<tr style="background-color:rgba(137, 196, 244, 1);">
<th>S.no</th>
<th>Task name</th>
<th>Completed at</th>
<th>Action</th>
</tr>
</thead>
<tbody>
@if(count($todolists))
@foreach($todolists as $list)
<tr>
<td>{{$list->id}}</td>
<td>{{$list->todo_tasks}}</td>
<td>{{$list->Completed_at}}</td>
<td style="display:flex;">
<a href="{{route('todolist.edit' , ['todolist' => $list->id])}}"><i style=" font-size:25px;" class="far fa-edit"></i></a>

{!! Form::open(array('url' => route('todolist.destroy' , ['todolist' => $list->id]) ,'method' => 'delete')) !!}

{!! Form::button('<i style="margin-left:5%; font-size:25px;" class="far fa-trash-alt"></i>' , ['type' => 'submit' , 'class' => 'btn btn-warning btn-sm']) !!}

{!! Form::close() !!}
</td>
</tr>
@endforeach
@else
<tr>
<td colspan="4">No data found</td>

</tr>
@endif
</tbody>
</table>
@endsection

